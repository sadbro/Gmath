# Gmath
A simple Python Math Library. Not Much More than that
